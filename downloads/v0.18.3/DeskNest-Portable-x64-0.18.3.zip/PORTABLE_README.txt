DeskNest portable build.
All mutable user data is created under data/.
Program updates preserve data/ and portable.flag.
